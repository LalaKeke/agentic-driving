"""Strict v2 contracts; v1 fields retain their original meaning."""
from copy import deepcopy
import hashlib
import json
import math
from pathlib import Path
from jsonschema import Draft7Validator

ROOT=Path(__file__).resolve().parents[1]
PROFILE='convex_disk_bicycle_v2'
class Failure(Exception):
    def __init__(self, code, message, category='interface_error', **details):
        super().__init__(message)
        self.record=dict(code=code,message=message,category=category,details=details,
                         repair_request='Revise decision or evidence-backed hypotheses; never relax safety silently.')
def need(ok,code,message,category='interface_error',**kw):
    if not ok: raise Failure(code,message,category,**kw)
def finite(x):
    if isinstance(x,float):need(math.isfinite(x),'NONFINITE','Nonfinite number')
    elif isinstance(x,dict):
        for v in x.values():finite(v)
    elif isinstance(x,list):
        for v in x:finite(v)
def validate(name,data):
    finite(data)
    schema=json.loads((ROOT/'schemas'/name).read_text())
    errors=list(Draft7Validator(schema).iter_errors(data))
    need(not errors,'SCHEMA_ERROR','Invalid '+name,paths=['/'.join(map(str,e.path)) for e in errors[:5]])
def digest(data):return hashlib.sha256(json.dumps(data,sort_keys=True,allow_nan=False).encode()).hexdigest()
def identity(scene,artifact):
    need(artifact['metadata']==scene['metadata'] and artifact['scene_digest']==digest(scene),
         'SCENE_VERSION_MISMATCH','Scene, revision, coordinate frame or content changed')
def artifact(scene,**kw):return dict(metadata=deepcopy(scene['metadata']),scene_digest=digest(scene),**kw)
def grid(meta):
    q=meta['horizon_s']/meta['step_s']
    need(abs(q-round(q))<1e-8 and 1<=q<=500,'TIME_GRID','Horizon must be an integer number of steps (1..500)')
    return [i*meta['step_s'] for i in range(round(q)+1)]
